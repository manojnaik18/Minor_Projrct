// Example using jQuery
$.ajax({
    url: '/doctor-data-upload',
    type: 'POST',
    data: formData,
    processData: false,
    contentType: false,
    success: function(response) {
        console.log('Data uploaded successfully:', response);
    },
    error: function(xhr, status, error) {
        console.error('Error:', error);
    }
});
